//
//  GXGlobalImports.h
//  GXModule_GeneXus
//

#ifndef GXGlobalImports_h
#define GXGlobalImports_h

@import GXCoreBL;
@import GXDataLayer;
@import GXFoundation;
@import GXObjectsModel;
@import GXStandardClasses;
@import YAJL;


#endif /* GXGlobalImports_h */