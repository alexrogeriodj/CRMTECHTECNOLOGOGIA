@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOARPreview <NSObject>

- (instancetype)init;

@property(nonatomic, readonly) BOOL isAvailable NS_SWIFT_NAME(isAvailable);

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOARPreview)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOARPreview> gxEOClass_GXEOARPreview;

@end

NS_ASSUME_NONNULL_END
