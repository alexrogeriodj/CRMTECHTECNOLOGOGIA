@import GXStandardClasses;

NS_ASSUME_NONNULL_BEGIN


@protocol GXEOProtocol_GXEOProgressIndicator <NSObject>

- (instancetype)init;

@property(nonatomic, readwrite) NSString * progressIndicatorClass NS_SWIFT_NAME(progressIndicatorClass);
@property(nonatomic, readwrite) NSInteger progressIndicatorType NS_SWIFT_NAME(progressIndicatorType);
@property(nonatomic, readwrite) NSString * progressIndicatorTitle NS_SWIFT_NAME(progressIndicatorTitle);
@property(nonatomic, readwrite) NSString * progressIndicatorDescription NS_SWIFT_NAME(progressIndicatorDescription);
@property(nonatomic, readwrite) NSInteger progressIndicatorMaxValue NS_SWIFT_NAME(progressIndicatorMaxValue);
@property(nonatomic, readwrite) NSInteger progressIndicatorValue NS_SWIFT_NAME(progressIndicatorValue);

- (void)show NS_SWIFT_NAME(show());
- (void)showWithTitle:(NSString *)title  NS_SWIFT_NAME(showWithTitle(_:));
- (void)showWithTitleAndDescription:(NSString *)title :(NSString *)description  NS_SWIFT_NAME(showWithTitleAndDescription(_:_:));
- (void)hide NS_SWIFT_NAME(hide());

@end

@interface GXExternalObjectBase (GXEOProtocol_GXEOProgressIndicator)

@property(class, nonatomic, readonly, null_unspecified) Class<GXEOProtocol_GXEOProgressIndicator> gxEOClass_GXEOProgressIndicator;

@end

NS_ASSUME_NONNULL_END
